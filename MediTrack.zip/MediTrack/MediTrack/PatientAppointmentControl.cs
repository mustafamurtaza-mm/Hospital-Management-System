﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Core;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class PatientAppointmentControl : UserControl
    {
        public PatientAppointmentControl()
        {
            InitializeComponent();
        }

        private void PatientAppointmentControl_Load(object sender, EventArgs e)
        {
            LoadDoctors();
            dgvMyAppointments.CellClick += dgvMyAppointments_CellClick;
        }
        private void LoadDoctors()
        {
            DataTable table = new DataTable();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(
                "SELECT d.DoctorID, u.FirstName + ' ' + u.LastName AS Name FROM Doctors d JOIN Users u ON d.UserID = u.UserID", conn);
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbDoctors.DataSource = table;
            cmbDoctors.DisplayMember = "Name";
            cmbDoctors.ValueMember = "DoctorID";
        }
        private int GetPatientID()
        {
            int userID = SessionManager.GetInstance().UserID;

            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT PatientID FROM Patients WHERE UserID = @uid", conn);
            cmd.Parameters.AddWithValue("@uid", userID);
            conn.Open();

            int patientID = Convert.ToInt32(cmd.ExecuteScalar());

            conn.Close();
            return patientID;
        }

        private void btnBookAppointment_Click(object sender, EventArgs e)
        {
            var appointment = new AppointmentModel
            {
                PatientID = GetPatientID(),
                DoctorID = (int)cmbDoctors.SelectedValue,
                AppointmentDate = dtpAppointmentDate.Value,
                Reason = txtReason.Text,
                Notes = txtNotes.Text
            };

            AppointmentController.AddAppointment(appointment);
            MessageBox.Show("Appointment booked!");
            LoadMyAppointments();
        }
        private void LoadMyAppointments()
        {
            int patientID = GetPatientID();
            var all = AppointmentController.GetAllAppointments();
            var mine = all.Where(a => a.PatientID == patientID).ToList();
            dgvMyAppointments.DataSource = mine;
        }

        int selectedAppointmentID = 0;

        private void dgvMyAppointments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
                selectedAppointmentID = Convert.ToInt32(dgvMyAppointments.Rows[e.RowIndex].Cells["AppointmentID"].Value);
        }
        private void btnCancelAppointment_Click(object sender, EventArgs e)
        {
            if (selectedAppointmentID == 0)
            {
                MessageBox.Show("Please select an appointment.");
                return;
            }

            AppointmentController.CancelAppointment(selectedAppointmentID);
            MessageBox.Show("Appointment cancelled.");
            LoadMyAppointments();
        }

        
    }
}
