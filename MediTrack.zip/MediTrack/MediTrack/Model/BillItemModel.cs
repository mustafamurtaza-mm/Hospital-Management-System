﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Model
{
    internal class BillItemModel
    {
        public int BillItemID;
        public int BillID;
        public string ItemType;
        public string Description;
        public int Quantity;
        public decimal UnitPrice;
        public decimal Amount;
    }
}
