﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Model
{
    public class AppointmentModel
    {
        public int AppointmentID;
        public int PatientID;
        public int DoctorID;
        public DateTime AppointmentDate;
        public string Status = "Scheduled";
        public string Reason;
        public string Notes;
    }
}
