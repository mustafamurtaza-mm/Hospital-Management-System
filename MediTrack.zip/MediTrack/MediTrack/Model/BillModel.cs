﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Model
{
    public class BillModel
    {
        public int BillID;
        public int PatientID;
        public DateTime BillDate;
        public decimal TotalAmount;
        public decimal PaidAmount;
        public string Status;
        public string PaymentMethod;
        public string Notes;
    }
}
