﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Model
{
    internal class DoctorModel
    {
        public int DoctorID;
        public int UserID;
        public string Specialization;
        public string LicenseNumber;
        public string Department;
        public TimeSpan AvailableFrom;
        public TimeSpan AvailableTo;
    }
}
