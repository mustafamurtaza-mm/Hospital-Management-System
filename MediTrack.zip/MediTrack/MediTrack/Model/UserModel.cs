﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack
{
    internal class UserModel
    {
        public int UserID;
        public string Username;
        public string Password;
        public string Role = "Patient"; // fixed role for this module
        public string FirstName;
        public string LastName;
        public string Email;
        public string Phone;
    }
}
