﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Model
{
    internal class MedicineModel
    {
        public int MedicineID;
        public string Name;
        public string Description;
        public string Category; 
        public decimal UnitPrice;   
        public int StockQuantity;
        public DateTime ExpiryDate;
        public string Supplier;
    }
}
