﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack
{
    internal class PatientModel
    {

        public int PatientID;
        public int UserID;  // FK to Users
        public DateTime DateOfBirth;
            public string Gender;
            public string BloodType;
            public string Address; 
            public string EmergencyContact;
            public string EmergencyPhone;
            public string InsuranceProvider;
            public string InsurancePolicyNumber;
        

    }
}
