﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Core;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class ReceptionistControl : UserControl
    {
        public ReceptionistControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnResetPharmacist_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLoginPharmacist_Click(object sender, EventArgs e)
        {
            string hashedPassword = SecurityHelper.HashPassword(txtReceptionistPassword.Text);

            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE Username=@u AND Password=@p AND Role='Receptionist'", conn);

            cmd.Parameters.AddWithValue("@u", txtReceptionistUsername.Text);
            cmd.Parameters.AddWithValue("@p", hashedPassword); 

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Successful doctor login
                int userId = Convert.ToInt32(reader["UserID"]);
                SessionManager.GetInstance().SetUser(txtReceptionistUsername.Text, "Receptionist", userId);
                new ReceptionistDashboard().Show();
                this.Hide(); // or raise event to main form
            }
            else
            {
                MessageBox.Show("Invalid Receptionist Credentials.");
            }
            conn.Close();
        }
    }
}
