﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediTrack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            IModuleFactory factory = new ModuleControlFactory();
            LoadUserControl(factory.CreateControl("Pharmacist"));
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadUserControl(new AdminControl());

            DatabaseConnection.TestConnection();
        }

        private void LoadUserControl(UserControl uc)
        {
            mainPanel.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            mainPanel.Controls.Add(uc);
        }

        private void btnAdmin_Click(object sender, EventArgs e)
        {
            IModuleFactory factory = new ModuleControlFactory();
            LoadUserControl(factory.CreateControl("Admin")); 
        }

        private void btnDoctor_Click(object sender, EventArgs e)
        {
            IModuleFactory factory = new ModuleControlFactory();
            LoadUserControl(factory.CreateControl("Doctor"));
        }

        private void btnPatient_Click(object sender, EventArgs e)
        {
            IModuleFactory factory = new ModuleControlFactory();
            LoadUserControl(factory.CreateControl("Patient"));
        }

        private void btnReceptionist_Click(object sender, EventArgs e)
        {
            IModuleFactory factory = new ModuleControlFactory();
            LoadUserControl(factory.CreateControl("Receptionist"));

        }
        public class DatabaseConnection
        {
            private static SqlConnection _connection;
            private static readonly string _connectionString =
                "Data Source=DESKTOP-BK7KCDQ\\SQLEXPRESS;Initial Catalog=MediTrack;Integrated Security=True;";

            private DatabaseConnection() { }

            public static SqlConnection GetConnection()
            {
                return new SqlConnection(_connectionString);
            }


            public static void TestConnection()
            {
                try
                {
                    using (var conn = GetConnection())
                    {
                        conn.Open();
                        MessageBox.Show("Connection successful!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Connection failed: {ex.Message}");
                }
            }
        }

    }
}
