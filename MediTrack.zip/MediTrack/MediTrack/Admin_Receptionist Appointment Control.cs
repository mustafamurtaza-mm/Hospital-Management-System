﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class Admin_Receptionist_Appointment_Control : UserControl
    {
        public Admin_Receptionist_Appointment_Control()
        {
            InitializeComponent();
        }

        private void Admin_Receptionist_Appointment_Control_Load(object sender, EventArgs e)
        {
            dgvAppointments.AutoGenerateColumns = true;
            LoadPatients();
            LoadDoctors();
            LoadAppointments();
            dgvAppointments.CellClick += dgvAppointments_CellClick;
        }
        private void LoadPatients()
        {
            DataTable table = new DataTable();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT p.PatientID, u.FirstName + ' ' + u.LastName AS Name FROM Patients p JOIN Users u ON p.UserID = u.UserID", conn);
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbPatients.DataSource = table;
            cmbPatients.DisplayMember = "Name";
            cmbPatients.ValueMember = "PatientID";
        }

        private void LoadDoctors()
        {
            DataTable table = new DataTable();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT d.DoctorID, u.FirstName + ' ' + u.LastName AS Name FROM Doctors d JOIN Users u ON d.UserID = u.UserID", conn);
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbDoctors.DataSource = table;
            cmbDoctors.DisplayMember = "Name";
            cmbDoctors.ValueMember = "DoctorID";
        }

        private void LoadAppointments()
        {
            dgvAppointments.DataSource = null;
            dgvAppointments.DataSource = AppointmentController.GetAllAppointments();
            dgvAppointments.Refresh();
            var data = AppointmentController.GetAllAppointments();
            dgvAppointments.DataSource = data;
        }

        private void btnBookAppointment_Click(object sender, EventArgs e)
        {
            var appointment = new AppointmentModel
            {
                PatientID = (int)cmbPatients.SelectedValue,
                DoctorID = (int)cmbDoctors.SelectedValue,
                AppointmentDate = dtpAppointmentDate.Value,
                Reason = txtReason.Text,
                Notes = txtNotes.Text,
                Status = "Scheduled"
            };

            AppointmentController.AddAppointment(appointment);
            MessageBox.Show("Appointment booked!");
            LoadAppointments();
        }

        int selectedAppointmentId = 0;

        private void dgvAppointments_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedAppointmentId = Convert.ToInt32(dgvAppointments.Rows[e.RowIndex].Cells["AppointmentID"].Value);
            }
        }

        private void btnCancelAppointment_Click(object sender, EventArgs e)
        {
            if (selectedAppointmentId == 0)
            {
                MessageBox.Show("Please select an appointment.");
                return;
            }

            AppointmentController.CancelAppointment(selectedAppointmentId);
            MessageBox.Show("Appointment cancelled.");
            LoadAppointments();
        }

        
    }
}
