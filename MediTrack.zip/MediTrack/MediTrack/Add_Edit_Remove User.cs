﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class Add_Edit_Remove_User : UserControl
    {
        public Add_Edit_Remove_User()
        {
            InitializeComponent();
            LoadUsers();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void LoadUsers()
        {
            try
            {
                using (SqlConnection conn = DatabaseConnection.GetConnection())
                {
                    string query = "SELECT UserID, Username, Role, FirstName, LastName, Email FROM Users";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    dgvUsers.DataSource = dt;
                    dgvUsers.Columns["UserID"].Visible = false; // Hide ID column
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading users: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (var form = new AddEditUserForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                    LoadUsers(); // Refresh after adding
            }
        }

        

        

        private void btnAdd_Click_1(object sender, EventArgs e)
        {
            using (var form = new AddEditUserForm())
            {
                if (form.ShowDialog() == DialogResult.OK)
                    LoadUsers(); // Refresh after adding
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0) return;

            int userId = (int)dgvUsers.SelectedRows[0].Cells["UserID"].Value;
            using (var form = new AddEditUserForm(userId))
            {
                if (form.ShowDialog() == DialogResult.OK)
                    LoadUsers(); // Refresh after editing
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvUsers.SelectedRows.Count == 0) return;

            int userId = (int)dgvUsers.SelectedRows[0].Cells["UserID"].Value;
            string username = dgvUsers.SelectedRows[0].Cells["Username"].Value.ToString();

            if (MessageBox.Show($"Delete user '{username}'?", "Confirm",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    using (SqlConnection conn = DatabaseConnection.GetConnection())
                    {
                        SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE UserID = @UserID", conn);
                        cmd.Parameters.AddWithValue("@UserID", userId);
                        conn.Open();
                        cmd.ExecuteNonQuery();
                        LoadUsers(); // Refresh
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}
