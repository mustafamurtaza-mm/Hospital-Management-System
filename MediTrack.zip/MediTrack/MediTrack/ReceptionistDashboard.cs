﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediTrack
{
    public partial class ReceptionistDashboard : Form
    {
        public ReceptionistDashboard()
        {
            InitializeComponent();
        }

        private void LoadUserControl(UserControl uc)
        {
            ReceptionistPanel.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            ReceptionistPanel.Controls.Add(uc);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            LoadUserControl (new Admin_Receptionist_Billing_Control()); 
        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadUserControl(new Admin_Receptionist_Appointment_Control());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadUserControl(new PatientManagementControl());
        }
    }
}
