﻿namespace MediTrack
{
    partial class DoctorAppointmentControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgvDoctorAppointments = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctorAppointments)).BeginInit();
            this.SuspendLayout();
            // 
            // dgvDoctorAppointments
            // 
            this.dgvDoctorAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoctorAppointments.Location = new System.Drawing.Point(124, 177);
            this.dgvDoctorAppointments.Name = "dgvDoctorAppointments";
            this.dgvDoctorAppointments.RowHeadersWidth = 51;
            this.dgvDoctorAppointments.RowTemplate.Height = 24;
            this.dgvDoctorAppointments.Size = new System.Drawing.Size(824, 150);
            this.dgvDoctorAppointments.TabIndex = 0;
            // 
            // DoctorAppointmentControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.dgvDoctorAppointments);
            this.Name = "DoctorAppointmentControl";
            this.Size = new System.Drawing.Size(1076, 789);
            this.Load += new System.EventHandler(this.DoctorAppointmentControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctorAppointments)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvDoctorAppointments;
    }
}
