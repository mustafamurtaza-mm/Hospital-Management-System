﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Core
{
    public class SessionManager
    {
        private static SessionManager _instance;
        private static readonly object _lock = new object();

        public string Username;
        public string Role;
        public int UserID;

        private SessionManager() { }

        public static SessionManager GetInstance()
        {
            lock (_lock)
            {
                if (_instance == null)
                    _instance = new SessionManager();

                return _instance;
            }
        }

        public void SetUser(string username, string role, int userID)
        {
            Username = username;
            Role = role;
            UserID = userID;
        }

        public void ClearSession()
        {
            Username = null;
            Role = null;
            UserID = 0;
        }
    }

}
