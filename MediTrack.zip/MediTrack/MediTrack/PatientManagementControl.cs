﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class PatientManagementControl : UserControl
    {
        public PatientManagementControl()
        {
            InitializeComponent();
            LoadPatients();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void LoadPatients()
        {
            dgvPatients.DataSource = null; // Clear any previous data
            var patientList = PatientController.GetAllPatients();

            // Convert Tuple<UserModel, PatientModel> into a flat table
            var displayList = patientList.Select(p => new
            {
                p.Item1.UserID,
                p.Item1.Username,
                p.Item1.FirstName,
                p.Item1.LastName,
                p.Item1.Email,
                p.Item1.Phone,
                p.Item2.DateOfBirth,
                p.Item2.Gender,
                p.Item2.BloodType,
                p.Item2.Address,
                p.Item2.EmergencyContact,
                p.Item2.EmergencyPhone,
                p.Item2.InsuranceProvider,
                p.Item2.InsurancePolicyNumber
            }).ToList();

            dgvPatients.DataSource = displayList;
        }

        private void ClearFields()
        {
            
            dtpDOB.Value = DateTime.Now;
            cmbGender.SelectedIndex = -1;
            cmbBloodType.SelectedIndex = -1;
            txtAddress.Clear();
            txtEmergencyContact.Clear();
            txtEmergencyPhone.Clear();
            txtInsurance.Clear();
            txtPolicy.Clear();

            selectedUserID = 0; // reset selection
        }


        private void btnAddpatient_Click(object sender, EventArgs e)
        {
            if (cmbPatientUsers.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a patient user.");
                return;
            }

            int selectedUserID = (int)cmbPatientUsers.SelectedValue;

            // Check if patient already has details
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Patients WHERE UserID = @uid", conn);
            checkCmd.Parameters.AddWithValue("@uid", selectedUserID);
            conn.Open();
            int exists = (int)checkCmd.ExecuteScalar();
            conn.Close();

            if (exists > 0)
            {
                MessageBox.Show("This user already has patient information.");
                return;
            }

            var patient = new PatientModel
            {
                UserID = selectedUserID,
                DateOfBirth = dtpDOB.Value,
                Gender = cmbGender.Text,
                BloodType = cmbBloodType.Text,
                Address = txtAddress.Text,
                EmergencyContact = txtEmergencyContact.Text,
                EmergencyPhone = txtEmergencyPhone.Text,
                InsuranceProvider = txtInsurance.Text,
                InsurancePolicyNumber = txtPolicy.Text
            };

            PatientController.AddPatientDetailsOnly(patient);
            MessageBox.Show("Patient information added.");
            LoadPatients();
            ClearFields();

        }


        int selectedUserID = 0;

        private void dgvPatients_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvPatients.Rows[e.RowIndex];
                selectedUserID = Convert.ToInt32(row.Cells["UserID"].Value);

                

                // patient info
                dtpDOB.Value = Convert.ToDateTime(row.Cells["DateOfBirth"].Value);
                cmbGender.Text = row.Cells["Gender"].Value.ToString();
                cmbBloodType.Text = row.Cells["BloodType"].Value.ToString();
                txtAddress.Text = row.Cells["Address"].Value.ToString();
                txtEmergencyContact.Text = row.Cells["EmergencyContact"].Value.ToString();
                txtEmergencyPhone.Text = row.Cells["EmergencyPhone"].Value.ToString();
                txtInsurance.Text = row.Cells["InsuranceProvider"].Value.ToString();
                txtPolicy.Text = row.Cells["InsurancePolicyNumber"].Value.ToString();
            }
        }

        private void btnUpdatePatient_Click(object sender, EventArgs e)
        {
            if (selectedUserID == 0)
            {
                MessageBox.Show("Please select a patient to update.");
                return;
            }

            var patient = new PatientModel
            {
                UserID = selectedUserID,
                DateOfBirth = dtpDOB.Value,
                Gender = cmbGender.Text,
                BloodType = cmbBloodType.Text,
                Address = txtAddress.Text,
                EmergencyContact = txtEmergencyContact.Text,
                EmergencyPhone = txtEmergencyPhone.Text,
                InsuranceProvider = txtInsurance.Text,
                InsurancePolicyNumber = txtPolicy.Text
            };

            PatientController.UpdatePatientDetails(patient);
            MessageBox.Show("Patient information updated.");
            LoadPatients();
            ClearFields();
        }

        private void btnDeletePatient_Click(object sender, EventArgs e)
        {
            
            if (selectedUserID == 0)
            {
                MessageBox.Show("Please select a patient to delete.");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete only the medical info? The user login will remain.", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                PatientController.DeletePatientDetails(selectedUserID);
                MessageBox.Show("Patient medical record deleted.");
                LoadPatients();
                ClearFields();
            }
        }

        

        private void PatientManagementControl_Load(object sender, EventArgs e)
        {
            LoadPatientUsers();
        }
        private void LoadPatientUsers()
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(
                "SELECT UserID, FirstName + ' ' + LastName AS FullName FROM Users WHERE Role = 'Patient'", conn);

            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbPatientUsers.DataSource = table;
            cmbPatientUsers.DisplayMember = "FullName";
            cmbPatientUsers.ValueMember = "UserID";
            cmbPatientUsers.SelectedIndex = -1;
        }

    }
}
