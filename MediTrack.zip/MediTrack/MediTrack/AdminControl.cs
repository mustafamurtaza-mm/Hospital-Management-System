﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MediTrack.Form1;
using MediTrack.Core;

namespace MediTrack
{
    public partial class AdminControl : UserControl
    {
        public AdminControl()
        {
            InitializeComponent();
        }

        private void btnLoginAdmin_Click(object sender, EventArgs e)
        {
            string hashedPassword = SecurityHelper.HashPassword(txtAdminPassword.Text);

            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE Username=@u AND Password=@p AND Role='Admin'", conn);

            cmd.Parameters.AddWithValue("@u", txtAdminUsername.Text);
            cmd.Parameters.AddWithValue("@p", hashedPassword); 

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Successful  login
                int userId = Convert.ToInt32(reader["UserID"]);
                SessionManager.GetInstance().SetUser(txtAdminUsername.Text, "Admin", userId);
                new AdminDashboard().Show();
                this.Hide(); // or raise event to main form
            }
            else
            {
                MessageBox.Show("Invalid Admin Credentials.");
            }
            conn.Close();
        }

        private void txtAdminUsername_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

