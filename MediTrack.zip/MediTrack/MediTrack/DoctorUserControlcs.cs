﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Core;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class DoctorUserControlcs : UserControl
    {
        public DoctorUserControlcs()
        {
            InitializeComponent();
        }

        private void btnLoginDoctor_Click(object sender, EventArgs e)
        {
            string hashedPassword = SecurityHelper.HashPassword(txtDoctorPassword.Text);
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE Username=@u AND Password=@p AND Role='Doctor'", conn);

            cmd.Parameters.AddWithValue("@u", txtDoctorUsername.Text);
            cmd.Parameters.AddWithValue("@p", hashedPassword); 

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Successful doctor login
                int userId = Convert.ToInt32(reader["UserID"]);
                SessionManager.GetInstance().SetUser(txtDoctorUsername.Text, "Doctor", userId);
                new DoctorDashboard().Show();
                this.Hide(); // or raise event to main form
            }
            else
            {
                MessageBox.Show("Invalid Doctor Credentials.");
            }
            conn.Close();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
