﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class DoctorManagementControl : UserControl
    {
        public DoctorManagementControl()
        {
            InitializeComponent();
        }

        int selectedDoctorUserID = 0;


        private void DoctorManagementControl_Load(object sender, EventArgs e)
        {
            dgvDoctors.CellClick += dgvDoctors_CellClick;

            LoadDoctorUsers();
            LoadDoctors();
        }

        private void LoadDoctors()
        {
            var doctorList = DoctorController.GetAllDoctors();

            var displayList = doctorList.Select(d => new
            {
                d.UserID,
                d.Specialization,
                d.LicenseNumber,
                d.Department,
                AvailableFrom = d.AvailableFrom.ToString(@"hh\:mm"),
                AvailableTo = d.AvailableTo.ToString(@"hh\:mm")
            }).ToList();

            dgvDoctors.DataSource = displayList;

            

        }

        private void ClearFields()
        {
            cmbDoctorUsers.SelectedIndex = -1;
            txtSpecialization.Clear();
            txtLicense.Clear();
            txtDepartment.Clear();
            dtpAvailableFrom.Value = DateTime.Now.Date.AddHours(9);   // default to 9 AM
            dtpAvailableTo.Value = DateTime.Now.Date.AddHours(17);    // default to 5 PM

            selectedDoctorUserID = 0;
        }


        private void LoadDoctorUsers()
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(
                "SELECT UserID, FirstName + ' ' + LastName AS FullName FROM Users WHERE Role = 'Doctor'", conn);

            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbDoctorUsers.DataSource = table;
            cmbDoctorUsers.DisplayMember = "FullName";
            cmbDoctorUsers.ValueMember = "UserID";
            cmbDoctorUsers.SelectedIndex = -1;
        }

        private void btnAddDoctor_Click(object sender, EventArgs e)
        {

            int selectedUserID = (int)cmbDoctorUsers.SelectedValue;

            // Check if already exists
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Doctors WHERE UserID = @uid", conn);
            checkCmd.Parameters.AddWithValue("@uid", selectedUserID);
            conn.Open();
            int exists = (int)checkCmd.ExecuteScalar();
            conn.Close();

            if (exists > 0)
            {
                MessageBox.Show("Doctor details already exist.");
                return;
            }

            var doctor = new DoctorModel
            {
                UserID = selectedUserID,
                Specialization = txtSpecialization.Text,
                LicenseNumber = txtLicense.Text,
                Department = txtDepartment.Text,
                AvailableFrom = dtpAvailableFrom.Value.TimeOfDay,
                AvailableTo = dtpAvailableTo.Value.TimeOfDay
            };

            DoctorController.AddDoctor(doctor);
            MessageBox.Show("Doctor info added.");
            LoadDoctors();
            ClearFields();
        }

        private void dgvDoctors_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dgvDoctors.Rows[e.RowIndex];

                    selectedDoctorUserID = Convert.ToInt32(row.Cells[0].Value);


                    cmbDoctorUsers.SelectedValue = selectedDoctorUserID;

                    txtSpecialization.Text = row.Cells["Specialization"].Value.ToString();
                    txtLicense.Text = row.Cells["LicenseNumber"].Value.ToString();
                    txtDepartment.Text = row.Cells["Department"].Value.ToString();

                    // ❗ These two are most likely to cause cast issues
                    dtpAvailableFrom.Value = DateTime.Today.Add(TimeSpan.Parse(row.Cells["AvailableFrom"].Value.ToString()));
                    dtpAvailableTo.Value = DateTime.Today.Add(TimeSpan.Parse(row.Cells["AvailableTo"].Value.ToString()));
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        

        private void btnUpdateDoctor_Click(object sender, EventArgs e)
        {
            if (selectedDoctorUserID == 0)
            {
                MessageBox.Show("Please select a doctor to update.");
                return;
            }

            var doctor = new DoctorModel
            {
                UserID = selectedDoctorUserID,
                Specialization = txtSpecialization.Text,
                LicenseNumber = txtLicense.Text,
                Department = txtDepartment.Text,
                AvailableFrom = dtpAvailableFrom.Value.TimeOfDay,
                AvailableTo = dtpAvailableTo.Value.TimeOfDay
            };

            DoctorController.UpdateDoctor(doctor);
            MessageBox.Show("Doctor information updated.");
            LoadDoctors();
            ClearFields();
        }

        private void btnDeleteDoctor_Click(object sender, EventArgs e)
        {
            if (selectedDoctorUserID == 0)
            {
                MessageBox.Show("Please select a doctor to delete.");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete this doctor’s information (login will remain)?", "Confirm", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                DoctorController.DeleteDoctor(selectedDoctorUserID);
                MessageBox.Show("Doctor information deleted.");
                LoadDoctors();
                ClearFields();
            }
        }
    }
}

