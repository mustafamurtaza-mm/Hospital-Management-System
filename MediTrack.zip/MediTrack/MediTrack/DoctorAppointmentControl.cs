﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Core;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class DoctorAppointmentControl : UserControl
    {
        public DoctorAppointmentControl()
        {
            InitializeComponent();
        }

        private void DoctorAppointmentControl_Load(object sender, EventArgs e)
        {
            LoadMyAppointments();
        }
        private void LoadMyAppointments()
        {
            int userId = SessionManager.GetInstance().UserID;

            // Get DoctorID using UserID
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmdDoctor = new SqlCommand("SELECT DoctorID FROM Doctors WHERE UserID = @uid", conn);
            cmdDoctor.Parameters.AddWithValue("@uid", userId);
            conn.Open();
            int doctorId = Convert.ToInt32(cmdDoctor.ExecuteScalar());
            conn.Close();

            // Join Appointments + Patients + Users to get details
            string query = @"
        SELECT 
            a.AppointmentDate,
            a.Status,
            a.Reason,
            a.Notes,
            u.FirstName + ' ' + u.LastName AS PatientName,
            u.Phone,
            u.Email
        FROM Appointments a
        JOIN Patients p ON a.PatientID = p.PatientID
        JOIN Users u ON p.UserID = u.UserID
        WHERE a.DoctorID = @docId
        ORDER BY a.AppointmentDate";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@docId", doctorId);
            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            dgvDoctorAppointments.DataSource = table;
        }
    }
}
