﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediTrack
{
    public partial class AdminDashboard : Form
    {
        public AdminDashboard()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadUserControl(new Add_Edit_Remove_User());
        }

        private void LoadUserControl(UserControl uc)
        {
            AdminPanel.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            AdminPanel.Controls.Add(uc);
        }

        private void AdminDashboard_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            LoadUserControl(new PatientManagementControl());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LoadUserControl(new Admin_Receptionist_Appointment_Control());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            LoadUserControl(new DoctorManagementControl());
        }

        private void button5_Click(object sender, EventArgs e)
        {
            LoadUserControl(new Admin_Receptionist_Billing_Control());
        }

        private void button6_Click(object sender, EventArgs e)
        {
            LoadUserControl(new ReportingControl());
        }
    }
}
