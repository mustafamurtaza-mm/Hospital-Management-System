﻿namespace MediTrack
{
    partial class DoctorManagementControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbDoctorUsers = new System.Windows.Forms.ComboBox();
            this.btnDeleteDoctor = new System.Windows.Forms.Button();
            this.btnUpdateDoctor = new System.Windows.Forms.Button();
            this.btnAddDoctor = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtpAvailableTo = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.dgvDoctors = new System.Windows.Forms.DataGridView();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.txtDepartment = new System.Windows.Forms.TextBox();
            this.txtLicense = new System.Windows.Forms.TextBox();
            this.dtpAvailableFrom = new System.Windows.Forms.DateTimePicker();
            this.txtSpecialization = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctors)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbDoctorUsers
            // 
            this.cmbDoctorUsers.FormattingEnabled = true;
            this.cmbDoctorUsers.Location = new System.Drawing.Point(913, 118);
            this.cmbDoctorUsers.Name = "cmbDoctorUsers";
            this.cmbDoctorUsers.Size = new System.Drawing.Size(121, 24);
            this.cmbDoctorUsers.TabIndex = 29;
            // 
            // btnDeleteDoctor
            // 
            this.btnDeleteDoctor.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteDoctor.Location = new System.Drawing.Point(895, 359);
            this.btnDeleteDoctor.Name = "btnDeleteDoctor";
            this.btnDeleteDoctor.Size = new System.Drawing.Size(155, 55);
            this.btnDeleteDoctor.TabIndex = 28;
            this.btnDeleteDoctor.Text = "Delete Doctor";
            this.btnDeleteDoctor.UseVisualStyleBackColor = true;
            this.btnDeleteDoctor.Click += new System.EventHandler(this.btnDeleteDoctor_Click);
            // 
            // btnUpdateDoctor
            // 
            this.btnUpdateDoctor.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdateDoctor.Location = new System.Drawing.Point(895, 281);
            this.btnUpdateDoctor.Name = "btnUpdateDoctor";
            this.btnUpdateDoctor.Size = new System.Drawing.Size(155, 55);
            this.btnUpdateDoctor.TabIndex = 27;
            this.btnUpdateDoctor.Text = "Update Doctor";
            this.btnUpdateDoctor.UseVisualStyleBackColor = true;
            this.btnUpdateDoctor.Click += new System.EventHandler(this.btnUpdateDoctor_Click);
            // 
            // btnAddDoctor
            // 
            this.btnAddDoctor.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddDoctor.Location = new System.Drawing.Point(895, 206);
            this.btnAddDoctor.Name = "btnAddDoctor";
            this.btnAddDoctor.Size = new System.Drawing.Size(155, 55);
            this.btnAddDoctor.TabIndex = 26;
            this.btnAddDoctor.Text = "Add Doctor";
            this.btnAddDoctor.UseVisualStyleBackColor = true;
            this.btnAddDoctor.Click += new System.EventHandler(this.btnAddDoctor_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dtpAvailableTo);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.dgvDoctors);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.txtDepartment);
            this.panel1.Controls.Add(this.txtLicense);
            this.panel1.Controls.Add(this.dtpAvailableFrom);
            this.panel1.Controls.Add(this.txtSpecialization);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Location = new System.Drawing.Point(27, 131);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(837, 604);
            this.panel1.TabIndex = 25;
            // 
            // dtpAvailableTo
            // 
            this.dtpAvailableTo.Location = new System.Drawing.Point(242, 325);
            this.dtpAvailableTo.Name = "dtpAvailableTo";
            this.dtpAvailableTo.Size = new System.Drawing.Size(200, 22);
            this.dtpAvailableTo.TabIndex = 26;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(41, 321);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(155, 26);
            this.label1.TabIndex = 25;
            this.label1.Text = "Available From";
            // 
            // dgvDoctors
            // 
            this.dgvDoctors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDoctors.Location = new System.Drawing.Point(46, 435);
            this.dgvDoctors.Name = "dgvDoctors";
            this.dgvDoctors.RowHeadersWidth = 51;
            this.dgvDoctors.RowTemplate.Height = 24;
            this.dgvDoctors.Size = new System.Drawing.Size(745, 117);
            this.dgvDoctors.TabIndex = 24;
            this.dgvDoctors.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDoctors_CellClick);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(41, 197);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(120, 26);
            this.label15.TabIndex = 5;
            this.label15.Text = "Department";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(41, 135);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(164, 26);
            this.label13.TabIndex = 6;
            this.label13.Text = "License Number";
            // 
            // txtDepartment
            // 
            this.txtDepartment.Location = new System.Drawing.Point(263, 197);
            this.txtDepartment.Name = "txtDepartment";
            this.txtDepartment.Size = new System.Drawing.Size(100, 22);
            this.txtDepartment.TabIndex = 10;
            // 
            // txtLicense
            // 
            this.txtLicense.Location = new System.Drawing.Point(263, 135);
            this.txtLicense.Name = "txtLicense";
            this.txtLicense.Size = new System.Drawing.Size(100, 22);
            this.txtLicense.TabIndex = 11;
            // 
            // dtpAvailableFrom
            // 
            this.dtpAvailableFrom.Location = new System.Drawing.Point(242, 260);
            this.dtpAvailableFrom.Name = "dtpAvailableFrom";
            this.dtpAvailableFrom.Size = new System.Drawing.Size(200, 22);
            this.dtpAvailableFrom.TabIndex = 12;
            // 
            // txtSpecialization
            // 
            this.txtSpecialization.Location = new System.Drawing.Point(263, 74);
            this.txtSpecialization.Name = "txtSpecialization";
            this.txtSpecialization.Size = new System.Drawing.Size(100, 22);
            this.txtSpecialization.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(41, 74);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(140, 26);
            this.label11.TabIndex = 1;
            this.label11.Text = "Specialization";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(41, 258);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(155, 26);
            this.label7.TabIndex = 13;
            this.label7.Text = "Available From";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(371, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(389, 42);
            this.label2.TabIndex = 30;
            this.label2.Text = "Doctor Info Management";
            // 
            // DoctorManagementControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbDoctorUsers);
            this.Controls.Add(this.btnDeleteDoctor);
            this.Controls.Add(this.btnUpdateDoctor);
            this.Controls.Add(this.btnAddDoctor);
            this.Controls.Add(this.panel1);
            this.Name = "DoctorManagementControl";
            this.Size = new System.Drawing.Size(1076, 789);
            this.Load += new System.EventHandler(this.DoctorManagementControl_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvDoctors)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbDoctorUsers;
        private System.Windows.Forms.Button btnDeleteDoctor;
        private System.Windows.Forms.Button btnUpdateDoctor;
        private System.Windows.Forms.Button btnAddDoctor;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.DataGridView dgvDoctors;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtDepartment;
        private System.Windows.Forms.TextBox txtLicense;
        private System.Windows.Forms.DateTimePicker dtpAvailableFrom;
        private System.Windows.Forms.TextBox txtSpecialization;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dtpAvailableTo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}
