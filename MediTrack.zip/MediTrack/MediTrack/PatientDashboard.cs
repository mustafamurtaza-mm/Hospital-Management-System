﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediTrack
{
    public partial class PatientDashboard : Form
    {
        public PatientDashboard()
        {
            InitializeComponent();
        }

        private void PatientDashboard_Load(object sender, EventArgs e)
        {
            
        }

        private void LoadUserControl(UserControl uc)
        {
            PatientPanel.Controls.Clear();
            uc.Dock = DockStyle.Fill;
            PatientPanel.Controls.Add(uc);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadUserControl (new PatientAppointmentControl());
        }
    }
}
