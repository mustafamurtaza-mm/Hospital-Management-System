﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MediTrack
{
    internal class ModuleControlFactory : IModuleFactory
    {
        public UserControl CreateControl(string type)
        {
            switch (type)
            {
                case "Admin":
                    return new AdminControl();
                case "Doctor":
                    return new DoctorUserControlcs();
                case "Patient":
                    return new PatientControl();
                case "Pharmacist":
                    return new PharmacistControl();
                case "Receptionist":
                    return new ReceptionistControl();
                default:
                    throw new ArgumentException("Unknown control type");
            }
        }
    }
}
