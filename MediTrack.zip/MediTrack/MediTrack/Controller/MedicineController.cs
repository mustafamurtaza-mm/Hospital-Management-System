﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack.Controller
{
    internal class MedicineController
    {
        public static void AddMedicine(MedicineModel m)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Medicines (Name, Description, Category, UnitPrice, StockQuantity, ExpiryDate, Supplier)
            VALUES (@Name, @Desc, @Cat, @Price, @Stock, @Expiry, @Supplier)", conn);

            cmd.Parameters.AddWithValue("@Name", m.Name);
            cmd.Parameters.AddWithValue("@Desc", m.Description);
            cmd.Parameters.AddWithValue("@Cat", m.Category);
            cmd.Parameters.AddWithValue("@Price", m.UnitPrice);
            cmd.Parameters.AddWithValue("@Stock", m.StockQuantity);
            cmd.Parameters.AddWithValue("@Expiry", m.ExpiryDate);
            cmd.Parameters.AddWithValue("@Supplier", m.Supplier);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static List<MedicineModel> GetAllMedicines()
        {
            List<MedicineModel> list = new List<MedicineModel>();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Medicines", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new MedicineModel
                {
                    MedicineID = (int)reader["MedicineID"],
                    Name = reader["Name"].ToString(),
                    Description = reader["Description"].ToString(),
                    Category = reader["Category"].ToString(),
                    UnitPrice = (decimal)reader["UnitPrice"],
                    StockQuantity = (int)reader["StockQuantity"],
                    ExpiryDate = (DateTime)reader["ExpiryDate"],
                    Supplier = reader["Supplier"].ToString()
                });
            }
            conn.Close();
            return list;
        }

        public static void UpdateMedicine(MedicineModel m)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            UPDATE Medicines SET
                Name = @Name,
                Description = @Desc,
                Category = @Cat,
                UnitPrice = @Price,
                StockQuantity = @Stock,
                ExpiryDate = @Expiry,
                Supplier = @Supplier
            WHERE MedicineID = @ID", conn);

            cmd.Parameters.AddWithValue("@ID", m.MedicineID);
            cmd.Parameters.AddWithValue("@Name", m.Name);
            cmd.Parameters.AddWithValue("@Desc", m.Description);
            cmd.Parameters.AddWithValue("@Cat", m.Category);
            cmd.Parameters.AddWithValue("@Price", m.UnitPrice);
            cmd.Parameters.AddWithValue("@Stock", m.StockQuantity);
            cmd.Parameters.AddWithValue("@Expiry", m.ExpiryDate);
            cmd.Parameters.AddWithValue("@Supplier", m.Supplier);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteMedicine(int id)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM Medicines WHERE MedicineID = @ID", conn);
            cmd.Parameters.AddWithValue("@ID", id);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
