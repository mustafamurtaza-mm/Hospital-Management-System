﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MediTrack.Form1;

namespace MediTrack.Controller
{
    internal class ReportController
    {
        public static DataTable GetAppointmentsByDate(DateTime date)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            SELECT a.AppointmentID, u.FirstName + ' ' + u.LastName AS Patient,
                   d.FirstName + ' ' + d.LastName AS Doctor, a.AppointmentDate, a.Status, a.Reason
            FROM Appointments a
            JOIN Patients p ON a.PatientID = p.PatientID
            JOIN Users u ON p.UserID = u.UserID
            JOIN Doctors doc ON a.DoctorID = doc.DoctorID
            JOIN Users d ON doc.UserID = d.UserID
            WHERE CAST(a.AppointmentDate AS DATE) = @date
            ORDER BY a.AppointmentDate", conn);

            cmd.Parameters.AddWithValue("@date", date.Date);
            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();
            return table;
        }

        public static DataTable GetBillingReport(DateTime from, DateTime to)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            SELECT b.BillID, u.FirstName + ' ' + u.LastName AS Patient, 
                   b.BillDate, b.TotalAmount, b.PaidAmount, b.Status, b.PaymentMethod
            FROM Billing b
            JOIN Patients p ON b.PatientID = p.PatientID
            JOIN Users u ON p.UserID = u.UserID
            WHERE b.BillDate BETWEEN @from AND @to
            ORDER BY b.BillDate DESC", conn);

            cmd.Parameters.AddWithValue("@from", from);
            cmd.Parameters.AddWithValue("@to", to);
            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();
            return table;
        }

        public static DataTable GetLowStockOrExpiredMedicines()
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            SELECT MedicineID, Name, StockQuantity, UnitPrice, ExpiryDate, 
                   CASE 
                       WHEN StockQuantity < 10 THEN 'Low Stock'
                       WHEN ExpiryDate < GETDATE() THEN 'Expired'
                       ELSE 'OK'
                   END AS Status
            FROM Medicines
            WHERE StockQuantity < 10 OR ExpiryDate < GETDATE()
            ORDER BY ExpiryDate", conn);

            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();
            return table;
        }
    }
}
