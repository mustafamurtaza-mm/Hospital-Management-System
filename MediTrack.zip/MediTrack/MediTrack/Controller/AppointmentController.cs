﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack.Controller
{
    public class AppointmentController
    {
        public static void AddAppointment(AppointmentModel a)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Appointments (PatientID, DoctorID, AppointmentDate, Status, Reason, Notes)
            VALUES (@pid, @did, @date, @status, @reason, @notes)", conn);

            cmd.Parameters.AddWithValue("@pid", a.PatientID);
            cmd.Parameters.AddWithValue("@did", a.DoctorID);
            cmd.Parameters.AddWithValue("@date", a.AppointmentDate);
            cmd.Parameters.AddWithValue("@status", a.Status);
            cmd.Parameters.AddWithValue("@reason", a.Reason);
            cmd.Parameters.AddWithValue("@notes", a.Notes ?? "");

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static List<AppointmentModel> GetAllAppointments()
        {
            List<AppointmentModel> list = new List<AppointmentModel>();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Appointments", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new AppointmentModel
                {
                    AppointmentID = (int)reader["AppointmentID"],
                    PatientID = (int)reader["PatientID"],
                    DoctorID = (int)reader["DoctorID"],
                    AppointmentDate = (DateTime)reader["AppointmentDate"],
                    Status = reader["Status"].ToString(),
                    Reason = reader["Reason"].ToString(),
                    Notes = reader["Notes"].ToString()
                });
            }
            conn.Close();
            return list;
        }

        public static void CancelAppointment(int appointmentId)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("UPDATE Appointments SET Status='Cancelled' WHERE AppointmentID=@id", conn);
            cmd.Parameters.AddWithValue("@id", appointmentId);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }
    }
}
