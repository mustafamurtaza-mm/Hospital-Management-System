﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack.Controller
{
    internal class BillingController
    {
        public static int AddBill(BillModel bill)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Billing (PatientID, TotalAmount, PaidAmount, Status, PaymentMethod, Notes)
            OUTPUT INSERTED.BillID
            VALUES (@PatientID, @TotalAmount, @PaidAmount, @Status, @Method, @Notes)", conn);

            cmd.Parameters.AddWithValue("@PatientID", bill.PatientID);
            cmd.Parameters.AddWithValue("@TotalAmount", bill.TotalAmount);
            cmd.Parameters.AddWithValue("@PaidAmount", bill.PaidAmount);
            cmd.Parameters.AddWithValue("@Status", bill.Status);
            cmd.Parameters.AddWithValue("@Method", bill.PaymentMethod);
            cmd.Parameters.AddWithValue("@Notes", bill.Notes);

            conn.Open();
            int billId = (int)cmd.ExecuteScalar();
            conn.Close();
            return billId;
        }

        public static void AddBillItem(BillItemModel item)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO BillItems (BillID, ItemType, Description, Quantity, UnitPrice, Amount)
            VALUES (@BillID, @Type, @Desc, @Qty, @Price, @Amt)", conn);

            cmd.Parameters.AddWithValue("@BillID", item.BillID);
            cmd.Parameters.AddWithValue("@Type", item.ItemType);
            cmd.Parameters.AddWithValue("@Desc", item.Description);
            cmd.Parameters.AddWithValue("@Qty", item.Quantity);
            cmd.Parameters.AddWithValue("@Price", item.UnitPrice);
            cmd.Parameters.AddWithValue("@Amt", item.Amount);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static DataTable GetAllBills()
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            SELECT b.BillID, u.FirstName + ' ' + u.LastName AS PatientName, 
                   b.BillDate, b.TotalAmount, b.PaidAmount, b.Status, b.PaymentMethod
            FROM Billing b
            JOIN Patients p ON b.PatientID = p.PatientID
            JOIN Users u ON p.UserID = u.UserID
            ORDER BY b.BillDate DESC", conn);

            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();
            return table;
        }

        public static void DeleteBill(int billId)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();

            // Delete items first due to FK
            SqlCommand cmdItems = new SqlCommand("DELETE FROM BillItems WHERE BillID = @id", conn);
            cmdItems.Parameters.AddWithValue("@id", billId);

            SqlCommand cmdBill = new SqlCommand("DELETE FROM Billing WHERE BillID = @id", conn);
            cmdBill.Parameters.AddWithValue("@id", billId);

            conn.Open();
            cmdItems.ExecuteNonQuery();
            cmdBill.ExecuteNonQuery();
            conn.Close();
        }

        public static DataTable GetPharmacistBills()
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
        SELECT b.BillID, u.FirstName + ' ' + u.LastName AS PatientName, 
               b.BillDate, b.TotalAmount, b.PaidAmount, b.Status
        FROM Billing b
        JOIN Patients p ON b.PatientID = p.PatientID
        JOIN Users u ON p.UserID = u.UserID
        WHERE b.PaymentMethod = 'Pharmacy'
        ORDER BY b.BillDate DESC", conn);

            DataTable table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();
            return table;
        }

    }
}
