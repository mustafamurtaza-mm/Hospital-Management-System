﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MediTrack.Form1;

namespace MediTrack
{
    internal class PatientController
    {
       
        public static void AddPatient(UserModel user, PatientModel patient)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            conn.Open();

            SqlCommand userCmd = new SqlCommand(@"
            INSERT INTO Users (Username, Password, Role, FirstName, LastName, Email, Phone)
            VALUES (@Username, @Password, @Role, @FirstName, @LastName, @Email, @Phone);
            SELECT SCOPE_IDENTITY();", conn);

            userCmd.Parameters.AddWithValue("@Username", user.Username);
            userCmd.Parameters.AddWithValue("@Password", user.Password);
            userCmd.Parameters.AddWithValue("@Role", "Patient");
            userCmd.Parameters.AddWithValue("@FirstName", user.FirstName);
            userCmd.Parameters.AddWithValue("@LastName", user.LastName);
            userCmd.Parameters.AddWithValue("@Email", user.Email);
            userCmd.Parameters.AddWithValue("@Phone", user.Phone);

            int newUserId = Convert.ToInt32(userCmd.ExecuteScalar());

            SqlCommand patientCmd = new SqlCommand(@"
            INSERT INTO Patients (UserID, DateOfBirth, Gender, BloodType, Address, EmergencyContact, EmergencyPhone, InsuranceProvider, InsurancePolicyNumber)
            VALUES (@UserID, @DOB, @Gender, @BloodType, @Address, @EC, @EP, @IP, @IPN)", conn);

            patientCmd.Parameters.AddWithValue("@UserID", newUserId);
            patientCmd.Parameters.AddWithValue("@DOB", patient.DateOfBirth);
            patientCmd.Parameters.AddWithValue("@Gender", patient.Gender);
            patientCmd.Parameters.AddWithValue("@BloodType", patient.BloodType);
            patientCmd.Parameters.AddWithValue("@Address", patient.Address);
            patientCmd.Parameters.AddWithValue("@EC", patient.EmergencyContact);
            patientCmd.Parameters.AddWithValue("@EP", patient.EmergencyPhone);
            patientCmd.Parameters.AddWithValue("@IP", patient.InsuranceProvider);
            patientCmd.Parameters.AddWithValue("@IPN", patient.InsurancePolicyNumber);

            patientCmd.ExecuteNonQuery();
            conn.Close();
        }

        public static List<(UserModel, PatientModel)> GetAllPatients()
        {
            var list = new List<(UserModel, PatientModel)>();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"SELECT u.*, p.* FROM Users u JOIN Patients p ON u.UserID = p.UserID", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                var user = new UserModel
                {
                    UserID = Convert.ToInt32(reader["UserID"]),
                    Username = reader["Username"].ToString(),
                    Role = reader["Role"].ToString(),
                    FirstName = reader["FirstName"].ToString(),
                    LastName = reader["LastName"].ToString(),
                    Email = reader["Email"].ToString(),
                    Phone = reader["Phone"].ToString()
                };

                var patient = new PatientModel
                {
                    PatientID = Convert.ToInt32(reader["PatientID"]),
                    UserID = user.UserID,
                    DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"]),
                    Gender = reader["Gender"].ToString(),
                    BloodType = reader["BloodType"].ToString(),
                    Address = reader["Address"].ToString(),
                    EmergencyContact = reader["EmergencyContact"].ToString(),
                    EmergencyPhone = reader["EmergencyPhone"].ToString(),
                    InsuranceProvider = reader["InsuranceProvider"].ToString(),
                    InsurancePolicyNumber = reader["InsurancePolicyNumber"].ToString()
                };

                list.Add((user, patient));
            }

            conn.Close();
            return list;
        }

        public static void UpdatePatient(UserModel user, PatientModel patient)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            conn.Open();

            // Update Users table
            SqlCommand userCmd = new SqlCommand(@"
        UPDATE Users SET
            Username = @Username,
            Password = @Password,
            FirstName = @FirstName,
            LastName = @LastName,
            Email = @Email,
            Phone = @Phone
        WHERE UserID = @UserID", conn);

            userCmd.Parameters.AddWithValue("@Username", user.Username);
            userCmd.Parameters.AddWithValue("@Password", user.Password);
            userCmd.Parameters.AddWithValue("@FirstName", user.FirstName);
            userCmd.Parameters.AddWithValue("@LastName", user.LastName);
            userCmd.Parameters.AddWithValue("@Email", user.Email);
            userCmd.Parameters.AddWithValue("@Phone", user.Phone);
            userCmd.Parameters.AddWithValue("@UserID", user.UserID);

            userCmd.ExecuteNonQuery();

            // Update Patients table
            SqlCommand patientCmd = new SqlCommand(@"
        UPDATE Patients SET
            DateOfBirth = @DOB,
            Gender = @Gender,
            BloodType = @BloodType,
            Address = @Address,
            EmergencyContact = @EC,
            EmergencyPhone = @EP,
            InsuranceProvider = @IP,
            InsurancePolicyNumber = @IPN
        WHERE UserID = @UserID", conn);

            patientCmd.Parameters.AddWithValue("@DOB", patient.DateOfBirth);
            patientCmd.Parameters.AddWithValue("@Gender", patient.Gender);
            patientCmd.Parameters.AddWithValue("@BloodType", patient.BloodType);
            patientCmd.Parameters.AddWithValue("@Address", patient.Address);
            patientCmd.Parameters.AddWithValue("@EC", patient.EmergencyContact);
            patientCmd.Parameters.AddWithValue("@EP", patient.EmergencyPhone);
            patientCmd.Parameters.AddWithValue("@IP", patient.InsuranceProvider);
            patientCmd.Parameters.AddWithValue("@IPN", patient.InsurancePolicyNumber);
            patientCmd.Parameters.AddWithValue("@UserID", patient.UserID);

            patientCmd.ExecuteNonQuery();

            conn.Close();
        }

        public static void DeletePatient(int userID)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            conn.Open();

            // First delete from Patients table
            SqlCommand patientCmd = new SqlCommand("DELETE FROM Patients WHERE UserID = @UserID", conn);
            patientCmd.Parameters.AddWithValue("@UserID", userID);
            patientCmd.ExecuteNonQuery();

            // Then delete from Users table
            SqlCommand userCmd = new SqlCommand("DELETE FROM Users WHERE UserID = @UserID", conn);
            userCmd.Parameters.AddWithValue("@UserID", userID);
            userCmd.ExecuteNonQuery();

            conn.Close();
        }
        public static void AddPatientDetailsOnly(PatientModel patient)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
        INSERT INTO Patients (UserID, DateOfBirth, Gender, BloodType, Address, EmergencyContact, EmergencyPhone, InsuranceProvider, InsurancePolicyNumber)
        VALUES (@UserID, @DOB, @Gender, @BloodType, @Address, @EC, @EP, @IP, @IPN)", conn);

            cmd.Parameters.AddWithValue("@UserID", patient.UserID);
            cmd.Parameters.AddWithValue("@DOB", patient.DateOfBirth);
            cmd.Parameters.AddWithValue("@Gender", patient.Gender);
            cmd.Parameters.AddWithValue("@BloodType", patient.BloodType);
            cmd.Parameters.AddWithValue("@Address", patient.Address);
            cmd.Parameters.AddWithValue("@EC", patient.EmergencyContact);
            cmd.Parameters.AddWithValue("@EP", patient.EmergencyPhone);
            cmd.Parameters.AddWithValue("@IP", patient.InsuranceProvider);
            cmd.Parameters.AddWithValue("@IPN", patient.InsurancePolicyNumber);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void UpdatePatientDetails(PatientModel patient)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
        UPDATE Patients SET
            DateOfBirth = @DOB,
            Gender = @Gender,
            BloodType = @BloodType,
            Address = @Address,
            EmergencyContact = @EC,
            EmergencyPhone = @EP,
            InsuranceProvider = @IP,
            InsurancePolicyNumber = @IPN
        WHERE UserID = @UserID", conn);

            cmd.Parameters.AddWithValue("@UserID", patient.UserID);
            cmd.Parameters.AddWithValue("@DOB", patient.DateOfBirth);
            cmd.Parameters.AddWithValue("@Gender", patient.Gender);
            cmd.Parameters.AddWithValue("@BloodType", patient.BloodType);
            cmd.Parameters.AddWithValue("@Address", patient.Address);
            cmd.Parameters.AddWithValue("@EC", patient.EmergencyContact);
            cmd.Parameters.AddWithValue("@EP", patient.EmergencyPhone);
            cmd.Parameters.AddWithValue("@IP", patient.InsuranceProvider);
            cmd.Parameters.AddWithValue("@IPN", patient.InsurancePolicyNumber);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeletePatientDetails(int userID)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM Patients WHERE UserID = @UserID", conn);
            cmd.Parameters.AddWithValue("@UserID", userID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }


    }

}

