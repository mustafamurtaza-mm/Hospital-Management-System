﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack.Controller
{
    internal class DoctorController
    {
        public static void AddDoctor(DoctorModel d)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            INSERT INTO Doctors (UserID, Specialization, LicenseNumber, Department, AvailableFrom, AvailableTo)
            VALUES (@uid, @spec, @lic, @dept, @from, @to)", conn);

            cmd.Parameters.AddWithValue("@uid", d.UserID);
            cmd.Parameters.AddWithValue("@spec", d.Specialization);
            cmd.Parameters.AddWithValue("@lic", d.LicenseNumber);
            cmd.Parameters.AddWithValue("@dept", d.Department);
            cmd.Parameters.AddWithValue("@from", d.AvailableFrom);
            cmd.Parameters.AddWithValue("@to", d.AvailableTo);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void UpdateDoctor(DoctorModel d)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand(@"
            UPDATE Doctors SET
            Specialization = @spec,
            LicenseNumber = @lic,
            Department = @dept,
            AvailableFrom = @from,
            AvailableTo = @to
            WHERE UserID = @uid", conn);

            cmd.Parameters.AddWithValue("@uid", d.UserID);
            cmd.Parameters.AddWithValue("@spec", d.Specialization);
            cmd.Parameters.AddWithValue("@lic", d.LicenseNumber);
            cmd.Parameters.AddWithValue("@dept", d.Department);
            cmd.Parameters.AddWithValue("@from", d.AvailableFrom);
            cmd.Parameters.AddWithValue("@to", d.AvailableTo);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static void DeleteDoctor(int userID)
        {
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("DELETE FROM Doctors WHERE UserID = @uid", conn);
            cmd.Parameters.AddWithValue("@uid", userID);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
        }

        public static List<DoctorModel> GetAllDoctors()
        {
            List<DoctorModel> list = new List<DoctorModel>();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Doctors", conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                list.Add(new DoctorModel
                {
                    DoctorID = (int)reader["DoctorID"],
                    UserID = (int)reader["UserID"],
                    Specialization = reader["Specialization"].ToString(),
                    LicenseNumber = reader["LicenseNumber"].ToString(),
                    Department = reader["Department"].ToString(),
                    AvailableFrom = (TimeSpan)reader["AvailableFrom"],
                    AvailableTo = (TimeSpan)reader["AvailableTo"]
                });
            }
            conn.Close();
            return list;
        }
    }
}
