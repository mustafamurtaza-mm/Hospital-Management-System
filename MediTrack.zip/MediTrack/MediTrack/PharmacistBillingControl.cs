﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class PharmacistBillingControl : UserControl
    {
        public PharmacistBillingControl()
        {
            InitializeComponent();
        }

        int selectedBillID = 0;


        private void PharmacistBillingControl_Load(object sender, EventArgs e)
        {
            LoadMedicines();
            LoadPatients();
            LoadPharmacistBills();

            dgvBillsHistory.CellClick += dgvBillsHistory_CellClick;
            btnDeletePharmacistBill.Click += button1_Click;


        }

        private List<BillItemModel> currentBillItems = new List<BillItemModel>();

        private void LoadMedicines()
        {
            var conn = DatabaseConnection.GetConnection();
            var cmd = new SqlCommand("SELECT MedicineID, Name, StockQuantity, UnitPrice FROM Medicines WHERE StockQuantity > 0", conn);
            var table = new DataTable();
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbMedicines.DataSource = table;
            cmbMedicines.DisplayMember = "Name";
            cmbMedicines.ValueMember = "MedicineID";
        }

        private void LoadPatients()
        {
            DataTable table = new DataTable();
            SqlConnection conn = DatabaseConnection.GetConnection();

            SqlCommand cmd = new SqlCommand(@"
        SELECT p.PatientID, u.FirstName + ' ' + u.LastName AS Name
        FROM Patients p
        INNER JOIN Users u ON p.UserID = u.UserID", conn);  // ✅ Only joins Users who are Patients

            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbPatients.DataSource = table;
            cmbPatients.DisplayMember = "Name";
            cmbPatients.ValueMember = "PatientID";
            cmbPatients.SelectedIndex = -1;
        }


        private void cmbMedicines_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbMedicines.SelectedItem is DataRowView row)
            {
                txtStockQty.Text = row["StockQuantity"].ToString();
                txtUnitPrice.Text = row["UnitPrice"].ToString();
            }
        }

        private void LoadPharmacistBills()
        {
            dgvBillsHistory.DataSource = BillingController.GetPharmacistBills();
        }



        private void btnAddItem_Click(object sender, EventArgs e)
        {
            int quantity = int.Parse(txtQuantitySold.Text);
            int available = int.Parse(txtStockQty.Text);

            if (quantity > available)
            {
                MessageBox.Show("Not enough stock!");
                return;
            }

            var item = new BillItemModel
            {
                ItemType = "Medicine",
                Description = cmbMedicines.Text,
                Quantity = quantity,
                UnitPrice = decimal.Parse(txtUnitPrice.Text),
                Amount = quantity * decimal.Parse(txtUnitPrice.Text)
            };

            currentBillItems.Add(item);
            dgvBillItems.DataSource = null;
            dgvBillItems.DataSource = currentBillItems.Select(i => new
            {
                i.Description,
                i.Quantity,
                i.UnitPrice,
                i.Amount
            }).ToList();

            txtTotalAmount.Text = currentBillItems.Sum(i => i.Amount).ToString("0.00");

            // Clear entry
            txtQuantitySold.Clear();
        }

        private void btnGenerateBill_Click(object sender, EventArgs e)
        {
            int patientID = (int)cmbPatients.SelectedValue;
            decimal total = currentBillItems.Sum(i => i.Amount);
            decimal paid = decimal.TryParse(txtPaidAmount.Text, out decimal p) ? p : 0;
            string status = (paid == 0) ? "Pending" : (paid < total) ? "Partial" : "Paid";

            var bill = new BillModel
            {
                PatientID = patientID,
                TotalAmount = total,
                PaidAmount = paid,
                Status = status,
                PaymentMethod = "Pharmacy",
                Notes = "Pharmacist bill"
            };

            int billID = BillingController.AddBill(bill);

            foreach (var item in currentBillItems)
            {
                item.BillID = billID;
                BillingController.AddBillItem(item);

                // ⬇️ Decrease stock
                var conn = DatabaseConnection.GetConnection();
                var cmd = new SqlCommand("UPDATE Medicines SET StockQuantity = StockQuantity - @Qty WHERE Name = @Name", conn);
                cmd.Parameters.AddWithValue("@Qty", item.Quantity);
                cmd.Parameters.AddWithValue("@Name", item.Description);
                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            MessageBox.Show("Pharmacy bill completed.");

            currentBillItems.Clear();
            dgvBillItems.DataSource = null;
            txtPaidAmount.Clear();
            txtTotalAmount.Clear();
            LoadMedicines(); // refresh inventory
            LoadPharmacistBills();
        }

        private void dgvBillsHistory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                selectedBillID = Convert.ToInt32(dgvBillsHistory.Rows[e.RowIndex].Cells["BillID"].Value);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (selectedBillID == 0)
            {
                MessageBox.Show("Please select a bill to delete.");
                return;
            }

            var confirm = MessageBox.Show("Are you sure you want to delete this bill?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                BillingController.DeleteBill(selectedBillID);
                MessageBox.Show("Bill deleted.");
                selectedBillID = 0;
                LoadPharmacistBills(); // Refresh the bills history
            }
        }
    }
}
