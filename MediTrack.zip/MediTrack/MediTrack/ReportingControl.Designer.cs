﻿namespace MediTrack
{
    partial class ReportingControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label9 = new System.Windows.Forms.Label();
            this.dtpReportDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLoadAppointments = new System.Windows.Forms.Button();
            this.dgvAppointments = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dtpBillFrom = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpBillTo = new System.Windows.Forms.DateTimePicker();
            this.btnLoadBilling = new System.Windows.Forms.Button();
            this.dgvBilling = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.btnLoadInventory = new System.Windows.Forms.Button();
            this.dgvInventory = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBilling)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).BeginInit();
            this.SuspendLayout();
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 22.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(470, 20);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(163, 42);
            this.label9.TabIndex = 32;
            this.label9.Text = "Reporting";
            // 
            // dtpReportDate
            // 
            this.dtpReportDate.Location = new System.Drawing.Point(232, 24);
            this.dtpReportDate.Name = "dtpReportDate";
            this.dtpReportDate.Size = new System.Drawing.Size(200, 22);
            this.dtpReportDate.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 26);
            this.label1.TabIndex = 34;
            this.label1.Text = "Report date";
            // 
            // btnLoadAppointments
            // 
            this.btnLoadAppointments.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadAppointments.Location = new System.Drawing.Point(129, 71);
            this.btnLoadAppointments.Name = "btnLoadAppointments";
            this.btnLoadAppointments.Size = new System.Drawing.Size(214, 68);
            this.btnLoadAppointments.TabIndex = 35;
            this.btnLoadAppointments.Text = "LoadAppointments";
            this.btnLoadAppointments.UseVisualStyleBackColor = true;
            this.btnLoadAppointments.Click += new System.EventHandler(this.btnLoadAppointments_Click);
            // 
            // dgvAppointments
            // 
            this.dgvAppointments.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvAppointments.Location = new System.Drawing.Point(28, 164);
            this.dgvAppointments.Name = "dgvAppointments";
            this.dgvAppointments.RowHeadersWidth = 51;
            this.dgvAppointments.RowTemplate.Height = 24;
            this.dgvAppointments.Size = new System.Drawing.Size(414, 150);
            this.dgvAppointments.TabIndex = 36;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dgvAppointments);
            this.panel1.Controls.Add(this.dtpReportDate);
            this.panel1.Controls.Add(this.btnLoadAppointments);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(27, 105);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(459, 467);
            this.panel1.TabIndex = 37;
            // 
            // dtpBillFrom
            // 
            this.dtpBillFrom.Location = new System.Drawing.Point(156, 11);
            this.dtpBillFrom.Name = "dtpBillFrom";
            this.dtpBillFrom.Size = new System.Drawing.Size(200, 22);
            this.dtpBillFrom.TabIndex = 37;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(29, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 26);
            this.label2.TabIndex = 38;
            this.label2.Text = "Bill From";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 26);
            this.label3.TabIndex = 39;
            this.label3.Text = "Bill To";
            // 
            // dtpBillTo
            // 
            this.dtpBillTo.Location = new System.Drawing.Point(156, 56);
            this.dtpBillTo.Name = "dtpBillTo";
            this.dtpBillTo.Size = new System.Drawing.Size(200, 22);
            this.dtpBillTo.TabIndex = 40;
            // 
            // btnLoadBilling
            // 
            this.btnLoadBilling.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadBilling.Location = new System.Drawing.Point(375, 7);
            this.btnLoadBilling.Name = "btnLoadBilling";
            this.btnLoadBilling.Size = new System.Drawing.Size(170, 78);
            this.btnLoadBilling.TabIndex = 37;
            this.btnLoadBilling.Text = "Load Billing";
            this.btnLoadBilling.UseVisualStyleBackColor = true;
            this.btnLoadBilling.Click += new System.EventHandler(this.btnLoadBilling_Click);
            // 
            // dgvBilling
            // 
            this.dgvBilling.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBilling.Location = new System.Drawing.Point(83, 100);
            this.dgvBilling.Name = "dgvBilling";
            this.dgvBilling.RowHeadersWidth = 51;
            this.dgvBilling.RowTemplate.Height = 24;
            this.dgvBilling.Size = new System.Drawing.Size(414, 150);
            this.dgvBilling.TabIndex = 37;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.dgvBilling);
            this.panel2.Controls.Add(this.dtpBillTo);
            this.panel2.Controls.Add(this.btnLoadBilling);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.dtpBillFrom);
            this.panel2.Location = new System.Drawing.Point(503, 65);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(548, 263);
            this.panel2.TabIndex = 41;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dgvInventory);
            this.panel3.Controls.Add(this.btnLoadInventory);
            this.panel3.Location = new System.Drawing.Point(503, 334);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(548, 238);
            this.panel3.TabIndex = 42;
            // 
            // btnLoadInventory
            // 
            this.btnLoadInventory.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoadInventory.Location = new System.Drawing.Point(174, 14);
            this.btnLoadInventory.Name = "btnLoadInventory";
            this.btnLoadInventory.Size = new System.Drawing.Size(214, 55);
            this.btnLoadInventory.TabIndex = 37;
            this.btnLoadInventory.Text = "Load Inventory";
            this.btnLoadInventory.UseVisualStyleBackColor = true;
            this.btnLoadInventory.Click += new System.EventHandler(this.btnLoadInventory_Click);
            // 
            // dgvInventory
            // 
            this.dgvInventory.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvInventory.Location = new System.Drawing.Point(83, 75);
            this.dgvInventory.Name = "dgvInventory";
            this.dgvInventory.RowHeadersWidth = 51;
            this.dgvInventory.RowTemplate.Height = 24;
            this.dgvInventory.Size = new System.Drawing.Size(414, 150);
            this.dgvInventory.TabIndex = 41;
            // 
            // ReportingControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Name = "ReportingControl";
            this.Size = new System.Drawing.Size(1076, 604);
            this.Load += new System.EventHandler(this.ReportingControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvAppointments)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBilling)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvInventory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker dtpReportDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLoadAppointments;
        private System.Windows.Forms.DataGridView dgvAppointments;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpBillFrom;
        private System.Windows.Forms.DateTimePicker dtpBillTo;
        private System.Windows.Forms.Button btnLoadBilling;
        private System.Windows.Forms.DataGridView dgvBilling;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dgvInventory;
        private System.Windows.Forms.Button btnLoadInventory;
    }
}
