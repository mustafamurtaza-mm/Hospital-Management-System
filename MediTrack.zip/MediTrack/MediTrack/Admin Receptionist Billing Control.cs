﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Model;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class Admin_Receptionist_Billing_Control : UserControl
    {
        private List<BillItemModel> currentBillItems = new List<BillItemModel>();
        public Admin_Receptionist_Billing_Control()
        {
            InitializeComponent();
            LoadPatients();
            LoadBills();

            dgvBills.CellClick += dgvBills_CellClick;

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LoadPatients()
        {
            DataTable table = new DataTable();
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT p.PatientID, u.FirstName + ' ' + u.LastName AS Name FROM Patients p JOIN Users u ON p.UserID = u.UserID", conn);
            conn.Open();
            table.Load(cmd.ExecuteReader());
            conn.Close();

            cmbPatients.DataSource = table;
            cmbPatients.DisplayMember = "Name";
            cmbPatients.ValueMember = "PatientID";
            cmbPatients.SelectedIndex = -1;
        }


        private void LoadBills()
        {
            dgvBills.DataSource = BillingController.GetAllBills();
        }


        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtItemType.Text) || string.IsNullOrWhiteSpace(txtDescription.Text) ||
                !int.TryParse(txtQuantity.Text, out int qty) || !decimal.TryParse(txtUnitPrice.Text, out decimal price))
            {
                MessageBox.Show("Please enter valid item details.");
                return;
            }

            var item = new BillItemModel
            {
                ItemType = txtItemType.Text,
                Description = txtDescription.Text,
                Quantity = qty,
                UnitPrice = price,
                Amount = qty * price
            };

            currentBillItems.Add(item);
            dgvBillItems.DataSource = null;
            dgvBillItems.DataSource = currentBillItems.Select(i => new
            {
                i.ItemType,
                i.Description,
                i.Quantity,
                i.UnitPrice,
                i.Amount
            }).ToList();

            txtTotalAmount.Text = currentBillItems.Sum(i => i.Amount).ToString("0.00");

            // Clear item fields
            txtItemType.Clear();
            txtDescription.Clear();
            txtQuantity.Clear();
            txtUnitPrice.Clear();
        }

        private void btnGenerateBill_Click(object sender, EventArgs e)
        {
            if (cmbPatients.SelectedIndex == -1 || currentBillItems.Count == 0)
            {
                MessageBox.Show("Please select a patient and add at least one item.");
                return;
            }

            decimal total = currentBillItems.Sum(i => i.Amount);
            decimal paid = decimal.TryParse(txtPaidAmount.Text, out decimal p) ? p : 0;
            string status = (paid == 0) ? "Pending" : (paid < total) ? "Partial" : "Paid";

            var bill = new BillModel
            {
                PatientID = (int)cmbPatients.SelectedValue,
                TotalAmount = total,
                PaidAmount = paid,
                Status = status,
                PaymentMethod = txtPaymentMethod.Text,
                Notes = txtNotes.Text
            };

            int billId = BillingController.AddBill(bill);

            foreach (var item in currentBillItems)
            {
                item.BillID = billId;
                BillingController.AddBillItem(item);
            }

            MessageBox.Show("Bill generated successfully.");

            // Reset
            currentBillItems.Clear();
            dgvBillItems.DataSource = null;
            txtTotalAmount.Clear();
            txtPaidAmount.Clear();
            txtPaymentMethod.Clear();
            txtNotes.Clear();
            LoadBills();
        }

        int selectedBillID = 0;


        private void dgvBills_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvBills.Rows[e.RowIndex];
                selectedBillID = Convert.ToInt32(row.Cells["BillID"].Value); // ✅ must match column name
                MessageBox.Show("Selected Bill ID: " + selectedBillID); // For debug            }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (selectedBillID == 0)
            {
                MessageBox.Show("Please select a bill to delete.");
                return;
            }

            DialogResult confirm = MessageBox.Show("Are you sure you want to delete this bill and its items?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                BillingController.DeleteBill(selectedBillID);
                MessageBox.Show("Bill deleted.");
                selectedBillID = 0;
                LoadBills(); // Refresh the grid
            }
        }
    }
}
