﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Core;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class PatientControl : UserControl
    {
        public PatientControl()
        {
            InitializeComponent();
        }

        private void btnLoginPatient_Click(object sender, EventArgs e)
        {
            string hashedPassword = SecurityHelper.HashPassword(txtPatientPassword.Text);
            SqlConnection conn = DatabaseConnection.GetConnection();
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE Username=@u AND Password=@p AND Role='Patient'", conn);

            cmd.Parameters.AddWithValue("@u", txtPatientUsername.Text);
            cmd.Parameters.AddWithValue("@p", hashedPassword); 

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                // Successful patient login
                int userId = Convert.ToInt32(reader["UserID"]);
                SessionManager.GetInstance().SetUser(txtPatientUsername.Text, "Patient", userId);
                new PatientDashboard().Show();
                this.Hide(); // or raise event to main form
            }
            else
            {
                MessageBox.Show("Invalid Patient Credentials.");
            }
            conn.Close();
        }
    }
}
