﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MediTrack.Controller;
using MediTrack.Model;

namespace MediTrack
{
    public partial class InventoryManagementControl : UserControl
    {
        public InventoryManagementControl()
        {
            InitializeComponent();
            LoadMedicines();
        }
        int selectedMedicineID = 0;
        private void LoadMedicines()
        {
            var list = MedicineController.GetAllMedicines();

            var displayList = list.Select(m => new
            {
                m.MedicineID,
                m.Name,
                m.Description,
                m.Category,
                m.UnitPrice,
                m.StockQuantity,
                m.ExpiryDate,
                m.Supplier
            }).ToList();

            dgvMedicines.DataSource = displayList;
        }

        private void ClearFields()
        {
            txtName.Clear();
            txtDescription.Clear();
            txtCategory.Clear();
            txtPrice.Clear();
            txtStock.Clear();
            txtSupplier.Clear();
            dtpExpiry.Value = DateTime.Today;
            selectedMedicineID = 0;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            var medicine = new MedicineModel
            {
                Name = txtName.Text,
                Description = txtDescription.Text,
                Category = txtCategory.Text,
                UnitPrice = decimal.Parse(txtPrice.Text),
                StockQuantity = int.Parse(txtStock.Text),
                ExpiryDate = dtpExpiry.Value,
                Supplier = txtSupplier.Text
            };

            MedicineController.AddMedicine(medicine);
            MessageBox.Show("Medicine added.");
            LoadMedicines();
            ClearFields();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedMedicineID == 0)
            {
                MessageBox.Show("Please select a medicine to update.");
                return;
            }

            var medicine = new MedicineModel
            {
                MedicineID = selectedMedicineID,
                Name = txtName.Text,
                Description = txtDescription.Text,
                Category = txtCategory.Text,
                UnitPrice = decimal.Parse(txtPrice.Text),
                StockQuantity = int.Parse(txtStock.Text),
                ExpiryDate = dtpExpiry.Value,
                Supplier = txtSupplier.Text
            };

            MedicineController.UpdateMedicine(medicine);
            MessageBox.Show("Medicine updated.");
            LoadMedicines();
            ClearFields();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedMedicineID == 0)
            {
                MessageBox.Show("Please select a medicine to delete.");
                return;
            }

            var confirm = MessageBox.Show("Are you sure?", "Confirm", MessageBoxButtons.YesNo);
            if (confirm == DialogResult.Yes)
            {
                MedicineController.DeleteMedicine(selectedMedicineID);
                MessageBox.Show("Medicine deleted.");
                LoadMedicines();
                ClearFields();
            }
        }

        private void dgvMedicines_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvMedicines.Rows[e.RowIndex];
                selectedMedicineID = Convert.ToInt32(row.Cells["MedicineID"].Value);

                txtName.Text = row.Cells["Name"].Value.ToString();
                txtDescription.Text = row.Cells["Description"].Value.ToString();
                txtCategory.Text = row.Cells["Category"].Value.ToString();
                txtPrice.Text = row.Cells["UnitPrice"].Value.ToString();
                txtStock.Text = row.Cells["StockQuantity"].Value.ToString();
                dtpExpiry.Value = Convert.ToDateTime(row.Cells["ExpiryDate"].Value);
                txtSupplier.Text = row.Cells["Supplier"].Value.ToString();
            }
        }
    }
}
