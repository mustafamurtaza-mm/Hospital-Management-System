﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static MediTrack.Form1;

namespace MediTrack
{
    public partial class AddEditUserForm : Form
    {
        private readonly int? _userId;
        private bool _isEditMode => _userId.HasValue;

        public AddEditUserForm(int? userId = null)
        {
            InitializeComponent();
            _userId = userId;

            // Configure form based on mode
            lblTitle.Text = _isEditMode ? "Edit User" : "Add New User";
            txtPassword.Enabled = !_isEditMode;
            txtConfirmPassword.Enabled = !_isEditMode;

            if (_isEditMode) LoadUserData();
        }

        private void LoadUserData()
        {
            try
            {
                using (SqlConnection conn = DatabaseConnection.GetConnection())
                {
                    string query = "SELECT * FROM Users WHERE UserID = @UserID";
                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@UserID", _userId.Value);

                    conn.Open();
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        txtUsername.Text = reader["Username"].ToString();
                        txtFirstName.Text = reader["FirstName"].ToString();
                        txtLastName.Text = reader["LastName"].ToString();
                        txtEmail.Text = reader["Email"].ToString();
                        txtPhone.Text = reader["Phone"].ToString();
                        cmbRole.Text = reader["Role"].ToString();
                        dtpCreatedDate.Value = reader["CreatedDate"] != DBNull.Value ?
                            (DateTime)reader["CreatedDate"] : DateTime.Now;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading user data: {ex.Message}");
            }
        }

        

        private bool ValidateInputs()
        {
            // Required fields
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Username is required!");
                return false;
            }

            if (!_isEditMode && string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Password is required for new users!");
                return false;
            }

            // Email validation
            if (!string.IsNullOrWhiteSpace(txtEmail.Text) && !IsValidEmail(txtEmail.Text))
            {
                MessageBox.Show("Please enter a valid email address!");
                return false;
            }

            return true;
        }

        private bool IsValidEmail(string email)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == email;
            }
            catch
            {
                return false;
            }
        }

        


        private void AddEditUserForm_Load(object sender, EventArgs e)
        {

        }

        private void chkShowPassword_CheckedChanged(object sender, EventArgs e)
        {
            txtPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
            txtConfirmPassword.PasswordChar = chkShowPassword.Checked ? '\0' : '*';
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            // Validate inputs
            if (!ValidateInputs()) return;

            try
            {
                using (SqlConnection conn = DatabaseConnection.GetConnection())
                {
                    string query = _isEditMode ?
                        @"UPDATE Users SET 
                        Username = @Username,
                        Password = CASE WHEN @Password IS NULL THEN Password ELSE @Password END,
                        Role = @Role,
                        FirstName = @FirstName,
                        LastName = @LastName,
                        Email = @Email,
                        Phone = @Phone
                      WHERE UserID = @UserID" :
                        @"INSERT INTO Users 
                      (Username, Password, Role, FirstName, LastName, Email, Phone, CreatedDate)
                      VALUES (@Username, @Password, @Role, @FirstName, @LastName, @Email, @Phone, GETDATE())";

                    SqlCommand cmd = new SqlCommand(query, conn);

                    // Common parameters
                    cmd.Parameters.AddWithValue("@Username", txtUsername.Text.Trim());
                    cmd.Parameters.AddWithValue("@Role", cmbRole.Text);
                    cmd.Parameters.AddWithValue("@FirstName", txtFirstName.Text.Trim());
                    cmd.Parameters.AddWithValue("@LastName", txtLastName.Text.Trim());
                    cmd.Parameters.AddWithValue("@Email", string.IsNullOrWhiteSpace(txtEmail.Text) ?
                        DBNull.Value : (object)txtEmail.Text.Trim());
                    cmd.Parameters.AddWithValue("@Phone", string.IsNullOrWhiteSpace(txtPhone.Text) ?
                        DBNull.Value : (object)txtPhone.Text.Trim());

                    // Password handling
                    if (!_isEditMode || !string.IsNullOrEmpty(txtPassword.Text))
                    {
                        if (txtPassword.Text != txtConfirmPassword.Text)
                        {
                            MessageBox.Show("Password and confirmation do not match!");
                            return;
                        }
                        cmd.Parameters.AddWithValue("@Password", SecurityHelper.HashPassword(txtPassword.Text));
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue("@Password", DBNull.Value);
                    }

                    if (_isEditMode)
                    {
                        cmd.Parameters.AddWithValue("@UserID", _userId.Value);
                    }

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    this.DialogResult = DialogResult.OK;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving user: {ex.Message}");
            }
        }
    }
}
