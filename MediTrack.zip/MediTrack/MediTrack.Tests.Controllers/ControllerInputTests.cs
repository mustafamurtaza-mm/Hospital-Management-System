﻿using MediTrack.Model;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Tests
{
    internal class ControllerInputTests
    {
        [Test]
        public void AddAppointment_WithValidData_ShouldNotThrow()
        {
            var appointment = new AppointmentModel
            {
                PatientID = 1,
                DoctorID = 1,
                AppointmentDate = DateTime.Now.AddDays(1),
                Reason = "Test"
            };

            Assert.DoesNotThrow(() =>
            {
                // Database call intentionally excluded
            });
        }

        [Test]
        public void AddAppointment_WithInvalidDate_ShouldBeDetectable()
        {
            var appointment = new AppointmentModel
            {
                AppointmentDate = DateTime.Now.AddDays(-1)
            };

            Assert.Less(appointment.AppointmentDate, DateTime.Now);
        }
    }
}
