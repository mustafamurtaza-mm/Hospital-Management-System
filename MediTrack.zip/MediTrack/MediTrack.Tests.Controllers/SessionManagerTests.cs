﻿using MediTrack.Core;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Tests
{
    internal class SessionManagerTests
    {
        [Test]
        public void SessionManager_ShouldBehaveAsSingleton()
        {
            var s1 = SessionManager.GetInstance();
            var s2 = SessionManager.GetInstance();

            Assert.AreSame(s1, s2);
        }

        [Test]
        public void ClearSession_ShouldResetValues()
        {
            var session = SessionManager.GetInstance();
            session.SetUser("admin", "Admin", 1);

            session.ClearSession();

            Assert.IsNull(session.Username);
            Assert.IsNull(session.Role);
            Assert.AreEqual(0, session.UserID);
        }
    }
}
