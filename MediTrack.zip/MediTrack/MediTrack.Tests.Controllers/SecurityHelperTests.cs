using NUnit.Framework;
using MediTrack.Controller;
using MediTrack.Model;
using System;
using System.Linq;
namespace MediTrack.Tests
{
    public class SecurityHelperTests
    {
        [Test]
        public void HashPassword_ShouldReturnNonPlainText()
        {
            string password = "password123";
            string hash = SecurityHelper.HashPassword(password);

            Assert.IsNotNull(hash);
            Assert.AreNotEqual(password, hash);
        }

        [Test]
        public void HashPassword_SameInput_ShouldProduceSameHash()
        {
            string hash1 = SecurityHelper.HashPassword("abc");
            string hash2 = SecurityHelper.HashPassword("abc");

            Assert.AreEqual(hash1, hash2);
        }

    }
}