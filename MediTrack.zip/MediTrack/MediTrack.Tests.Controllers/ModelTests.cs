﻿using MediTrack.Model;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediTrack.Tests
{
    internal class ModelTests
    {
        [Test]
        public void Appointment_DefaultStatus_ShouldBeScheduled()
        {
            var appointment = new AppointmentModel();
            Assert.AreEqual("Scheduled", appointment.Status);
        }

        [Test]
        public void Bill_WithZeroAmount_ShouldBeValid()
        {
            var bill = new BillModel { TotalAmount = 0 };
            Assert.AreEqual(0, bill.TotalAmount);
        }
    }
}
